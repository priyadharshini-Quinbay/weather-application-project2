package com.example.Forecast;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ForecastApplicationTests {

	@Test
	void contextLoads() {
	}

}
