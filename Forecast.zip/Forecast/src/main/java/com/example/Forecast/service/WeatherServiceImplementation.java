package com.example.Forecast.service;


import com.example.Forecast.entity.CurrentHourStatusEntity;
import com.example.Forecast.entity.CurrentWeekStatusEntity;
import com.example.Forecast.repository.CurrentHourStatusRepo;
import com.example.Forecast.repository.CurrentWeekStatusRepo;
import com.example.Forecast.repository.WeatherTypeRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Month;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Optional;

@Service
public class WeatherServiceImplementation implements WeatherService
{


    @Autowired
    CurrentHourStatusRepo currentHourStatusRepo;
    @Autowired
    CurrentWeekStatusRepo currentWeekStatusRepo;
    @Autowired
    WeatherTypeRepo weathertypeRepo;



    public void addWeatherHour(CurrentHourStatusEntity data) {
//            double z;
        if (data.getAltitude() != null || data.getCity() != null || data.getDate() != null || (data.getStartTime()>1||data.getStartTime()<24)|| data.getHumidity() != null || data.getTemperature() != null || data.getPressure() != null) {
            Optional<CurrentHourStatusEntity> ad = currentHourStatusRepo.findFirstByCityAndDateAndStartTime(data.getCity(),data.getDate(), data.getStartTime());
            if (ad.isPresent()) {
                ad.get().setHumidity(data.getHumidity());
                ad.get().setPressure(data.getPressure());
                ad.get().setTemperature(
                        data.getTemperature());
                ad.get().setWeatherType(data.getWeatherType());
                setCurrentWeek(data);
                currentHourStatusRepo.save(ad.get());
            } else {
                currentHourStatusRepo.save(data);
                setCurrentWeek(data);

            }
//                z=WeatherStatus(data.getPressure(),data.getTemperature(),data.getAltitude());
//                String status = weathertypeRepo.findByForecastNumber(z);
//           currentHourStatusRepo.save(data);
//            CurrentHourStatusEntity dataWeather = currentHourStatusRepo.save(new CurrentHourStatusEntity(data.getCity(), data.getAltitude(), data.getDate(), data.getStartTime(), data.getEndTime(), data.getHumidity(), data.getPressure(), "clouds", data.getTemperature()));
//                if (dataWeather.getId() != null) {
//                    return dataWeather;
//                } else {
//                    return null;
//                }
//            }
//            else
//                return null;


        }
    }
    public void addWeatherWeek(CurrentWeekStatusEntity data) {
//            double z;
        if (data.getWeatherType() != null || data.getCity() != null || data.getDate() != null || data.getAltitude() != null || data.getAvgHumidity() != null || data.getMaxTemperature() != null || data.getMinTemperature() != null || data.getAvgPressure() != null||data.getAvgTemperature() != null) {

//                z=WeatherStatus(data.getPressure(),data.getTemperature(),data.getAltitude());
//                String status = weathertypeRepo.findByForecastNumber(z);
            currentWeekStatusRepo.save(data);
//


        }
    }

    public void setCurrentWeek(CurrentHourStatusEntity week)

    {
        int t=0;
         float Pressure = 0,Temperature=0,Humidity=0,maxTemperature=0,minTemperature=week.getTemperature();
        Optional<CurrentWeekStatusEntity> filterrecord = currentWeekStatusRepo.findFirstByCityAndDate(week.getCity(),week.getDate());
        for (CurrentHourStatusEntity current : currentHourStatusRepo.findByCityAndDate(week.getCity(), week.getDate())) {
            t++;
            Pressure += current.getPressure();
            Temperature += current.getTemperature();
            Humidity += current.getHumidity();


            if (maxTemperature < current.getTemperature())
                maxTemperature = current.getTemperature();
            if (minTemperature > current.getTemperature())
                minTemperature = current.getTemperature();

        }
        if (filterrecord.isPresent()) {

            filterrecord.get().setCity(week.getCity());
            filterrecord.get().setAltitude(week.getAltitude());
            filterrecord.get().setDate(week.getDate());
            filterrecord.get().setAvgHumidity(Humidity/t);
            filterrecord.get().setAvgPressure(Pressure/t);
            filterrecord.get().setAvgTemperature(Temperature/t);
            filterrecord.get().setMaxTemperature(maxTemperature);
            filterrecord.get().setMinTemperature(minTemperature);
            filterrecord.get().setWeatherType(week.getWeatherType());
            currentWeekStatusRepo.save(filterrecord.get());
        }
        else {
            CurrentWeekStatusEntity data = new CurrentWeekStatusEntity(week.getCity(), week.getAltitude(), week.getDate(), week.getHumidity(), week.getPressure(), week.getTemperature(), week.getTemperature(), week.getTemperature(), week.getWeatherType());
            currentWeekStatusRepo.save(data);
        }

    }

    public double WeatherStatus(Float pressure,Float temperature,Float height){
        double calculate,atmospheric,z;
        calculate=1-((0.0065*height)/(temperature+0.0065*height+273.15));
        atmospheric=pressure*(Math.pow(calculate,-5.257));
        z=147-((5*atmospheric)/376);
        return z;
    }

    public Optional<CurrentHourStatusEntity> getCurrentWeather(String city, String date, int time) {
       return currentHourStatusRepo.findFirstByCityAndDateAndStartTime(city,date,time);
    }
    public List<CurrentWeekStatusEntity> getCurrentNextSix(String city, String date)
    {
        int totalnoofdays=0;
        LocalDate currentDate = LocalDate.parse(date);
        int day = currentDate.getDayOfMonth();
        int month = currentDate.getMonthValue();
        int year = currentDate.getYear();
        switch (month) {
            case 1:
            case 3:
            case 5:
            case 7:
            case 8:
            case 10:
            case 12:
                totalnoofdays = 31;
                break;
            case 4:
            case 6:
            case 9:
            case 11:
                totalnoofdays = 30;
                break;
            case 2:
                if ((year % 400 == 0) || (year % 4 == 0 && year % 100 != 0)) {
                    totalnoofdays = 29;
                } else {
                    totalnoofdays = 28;

                }
                break;
            default:
                totalnoofdays = 0;
        }


        List<CurrentWeekStatusEntity> sort=new ArrayList<>();

        List<CurrentWeekStatusEntity> six=currentWeekStatusRepo.findByCity(city) ;
        int tt=day+1;
        int csix=1;
        int check=0;
        Float altitude=0f;
              for(CurrentWeekStatusEntity sorts:six)
              {
                  altitude=sorts.getAltitude();
                  break;
              }



        while(tt<=totalnoofdays&&csix<=6) {
            for (CurrentWeekStatusEntity sixs : six) {
                LocalDate getdate = LocalDate.parse(sixs.getDate());
                int getday = getdate.getDayOfMonth();
                int getmonth = getdate.getMonthValue();
                int getyear = getdate.getYear();
                if (getday == tt&&getyear==year&&getmonth==month) {
                    sort.add(sixs);
                        check=1;
                    break;
                }
              }
            if(check==1)
                check=0;

             else {
                 String d=year+"-"+month+"-"+tt;
                 sort.add(new CurrentWeekStatusEntity("Not Available", city, altitude,d, 0.0f, 0.0f,0.0f,0.0f,0.0f,"Not Available"));
             }



            if(tt==totalnoofdays){
                tt=1;
                csix++;
                if(month==12)
                {
                    month=1;
                    year+=1;
                }
                else {
                    month+=1;
                }
            }
            else {
            tt++;
            csix++;}
        }
        return sort;
        }


public List<CurrentHourStatusEntity> sortList(String city, String date,int time){
    List<CurrentHourStatusEntity> sort=new ArrayList<>();

    List<CurrentHourStatusEntity> hour=currentHourStatusRepo.findByCityAndDate(city,date) ;
    int tt=time;
    while(tt<24) {
        for (CurrentHourStatusEntity hours : hour) {
            if (hours.getStartTime() == tt) {
                sort.add(hours);
                break;
            }
        }
        tt++;
    }
    return sort;
}
    public List<CurrentHourStatusEntity> getlist(List<CurrentHourStatusEntity> sort,int starttime)
    {
        List<CurrentHourStatusEntity> list=new ArrayList<>();

        Float altitude=0f;
        int t=0,checkpresent=0;
        int current=starttime+1;
        String city="";
        String date="";
        for(CurrentHourStatusEntity sorts:sort)
        {
            altitude=sorts.getAltitude();
            city=sorts.getCity();
            date=sorts.getDate();
            break;
        }
        while (t<6 && current<=23)
        {
            for(CurrentHourStatusEntity sorts:sort)
            {
                if(sorts.getStartTime()==current)
                {
                    list.add(sorts);
                    t++;
                    checkpresent=1;
                    current++;
                    break;
                }
            }
            if(checkpresent!=1) {
                list.add(new CurrentHourStatusEntity("Not Available",city, altitude, date, current, 0.0f, 0.0f,"Not Available",0.0f));
                t++;
                current++;
            }
            else
                checkpresent=0;
        }
        return  list;


    }
    public List<CurrentHourStatusEntity> getCurrentRange(String city, String date,int starttime) {
        List<CurrentHourStatusEntity> sort=sortList(city,date,starttime);
        List<CurrentHourStatusEntity> list=getlist(sort,starttime);
        int size=list.size();

        if(size<6)

        {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

            Calendar c = Calendar.getInstance();

            try {
                c.setTime(sdf.parse(date));
            } catch (ParseException e) {
                e.printStackTrace();
            }

            c.add(Calendar.DATE, 1);  // number of days to add

            date = sdf.format(c.getTime());
            sort = sortList(city,date,1 );
            List<CurrentHourStatusEntity> list2=getlist(sort,-1);

                for (CurrentHourStatusEntity counters : list2) {
                    if(size<6)
                    {
                    list.add(counters);

                    size++;
                }
                else
                    break;
            }

        }
        return  list;

    }


}
//    @Autowired
//    LikesRepository strp;
//    @Autowired
//    UserRepo user;
//    @Autowired
//    BrandRepo brand;
//
//
//    @Override
//    public List<Ads> getAllAds(String Username) {
//
//        List<UserEntity> list = user.findByUserName(Username);
//        List<String> list1 = new ArrayList<>();
//        if (list.size() != 0) {
//            list1 = list.get(0).getInterests();
//        }
//        List<Ads> list3 = str.findAll();
////        System.out.println(list3);
//
//        if (list1.size()==0) {
//            return list3;
//        } else {
//            List<Ads> list2 = new ArrayList<>();
//            for (String s : list1) {
//                list2.addAll(str.findByCategory(s));
//            }
//
//            if (list2.size() == 0) {
//                return null;
//            } else {
//                return list2;
//            }
//        }
//    }
//
//    @Override
//    public List<Ads> getAds() {
//
//
//        List<Ads> list2 = new ArrayList<>();
//        for (Ads stu : str.findAll()) {
//
//            list2.add(new Ads(stu.getId(), stu.getImage(), stu.getTitle(), stu.getCategory()));
//        }
//
//        if(list2.size() ==0){
//            return null;
//        }else{
//            return list2;
//        }
//
//    }
//    @Override
//    public List<Brands> getBrands() {
//
//
//        List<Brands> list2 = new ArrayList<>();
//        for (Brands stu : brand.findAll()) {
//
//            list2.add(new Brands(stu.getId(),stu.getImages(),stu.getName()));
//        }
//
//        if(list2.size() ==0){
//            return null;
//        }else{
//            return list2;
//        }
//
//    }
//
////        String[] category=null;
////        for(UserEntity u:user.findAll())
////        {
////            if(u.getUserName().equals(Username))
////                category=u.getInterests();
////        }
////        System.out.println(category);
////        List<Ads> list = new ArrayList<>();
////
//////            str.findAll().forEach(list::add);
//////        System.out.println(category);
////        for (int i = 0; i < category.length; i++) {
////
////
////            for (Ads stu : str.findAll()) {
////                if (category[i].equals(stu.getCategory())) {
////                    list.add(new Ads(stu.getId(), stu.getImage(), stu.getTitle(), stu.getCategory()));
////
////                }
////            }
////
////
////        }
////
//
//
//
//    @Override
//    public List<LikeAds> getAllLikes() {
//
//        List<LikeAds> list = new ArrayList<>();
//
//        for (LikeAds likeAds : strp.findAll()) {
//            LikeAds entity = new LikeAds();
//            entity.setId(likeAds.getId());
//            entity.setPlatform(likeAds.getPlatform());
//
//            entity.setUsername(likeAds.getUsername());
//            entity.setCount(likeAds.getCount());
//            entity.setCategory(likeAds.getCategory());
//            list.add(entity);
//        }
//
//        if(list.size() ==0){
//            return null;
//        }else{
//            return list;
//        }
//
//    }
//
//
//    @Override
//    public List<UserEntity> getUser() {
//
//        List<UserEntity> list = new ArrayList<>();
//
//        for (UserEntity user : user.findAll()) {
//            UserEntity entity = new UserEntity();
//            entity.setId(user.getId());
//            entity.setPlatform(user.getPlatform());
//
//            entity.setUserName(user.getUserName());
//            entity.setInterests(user.getInterests());
//
//            list.add(entity);
//        }
//
//        if(list.size() ==0){
//            return null;
//        }else{
//            return list;
//        }
//
//    }
//
//    @Override
//    public List<Analysis> Analysis() {
//
////        List<Ads> list = new ArrayList<>();
//
////            str.findAll().forEach(list::add);
////        System.out.println(category);
////        List<Analysis> analysis = ana.findAll();
//        int shop = 0, ent = 0, learn = 0, tech = 0, food = 0;
//        for (LikeAds likeAds : strp.findAll()) {
//            if (likeAds.getCategory().equalsIgnoreCase("shopping"))
//                shop += likeAds.getCount();
//            else if (likeAds.getCategory().equalsIgnoreCase("entertainment"))
//                ent += likeAds.getCount();
//            else if (likeAds.getCategory().equalsIgnoreCase("technology"))
//                tech += likeAds.getCount();
//            else if (likeAds.getCategory().equalsIgnoreCase("learning"))
//                learn += likeAds.getCount();
//            else if (likeAds.getCategory().equalsIgnoreCase("food"))
//                food += likeAds.getCount();
//
//
//        }
//
//        List<Analysis> list = new ArrayList<>();
//        list.add(new Analysis("shopping", shop));
//        list.add(new Analysis("entertainment", ent));
//        list.add(new Analysis("technology", tech));
//
//        list.add(new Analysis("learning", learn));
//
//        list.add(new Analysis("food", food));
//
//
//        if(list.size() ==0){
//            return null;
//        }else{
//            return list;
//        }
//
//
//    }
//
//    @Override
//    public List<Analysis> Analysis2() {
//
////        List<Ads> list = new ArrayList<>();
//
////            str.findAll().forEach(list::add);
////        System.out.println(category);
////        List<Analysis> analysis = ana.findAll();
//        int  quinbook = 0, quinoura = 0, pinstagram = 0;
//        for (UserEntity likeAds : user.findAll()) {
//            if (likeAds.getPlatform().equalsIgnoreCase("quinbook"))
//                quinbook +=1;
//            else if (likeAds.getPlatform().equalsIgnoreCase("quinoura"))
//                quinoura += 1;
//            else if (likeAds.getPlatform().equalsIgnoreCase("pinstagram"))
//                pinstagram += 1;
//
//
//        }
//
//        List<Analysis> list = new ArrayList<>();
//        list.add(new Analysis("quinbook", quinbook));
//        list.add(new Analysis("quinoura", quinoura));
//        list.add(new Analysis("pinstagram", pinstagram));
//
//
//
//
//        if(list.size() ==0){
//            return null;
//        }else{
//            return list;
//        }
//
//
//    }
//    @Override
//    public List<Analysis> Analysis3() {
//
//        String platform[]={"quinbook","quinoura","pinstagram"};
//        List<Analysis> list = new ArrayList<>();
//
//        for(int i=0;i<3;i++) {
//            List<LikeAds> list1 = strp.findByPlatform(platform[i]);
//
//            int shop = 0, ent = 0, learn = 0, tech = 0, food = 0;
//            for (LikeAds likeAds : list1) {
//
//                if (likeAds.getCategory().equalsIgnoreCase("shopping"))
//                    shop += likeAds.getCount();
//                else if (likeAds.getCategory().equalsIgnoreCase("entertainment"))
//                    ent += likeAds.getCount();
//                else if (likeAds.getCategory().equalsIgnoreCase("technology"))
//                    tech += likeAds.getCount();
//                else if (likeAds.getCategory().equalsIgnoreCase("learning"))
//                    learn += likeAds.getCount();
//                else if (likeAds.getCategory().equalsIgnoreCase("food"))
//                    food += likeAds.getCount();
//            }
//            list.add(new Analysis("shopping", shop, platform[i]));
//            list.add(new Analysis("entertainment", ent, platform[i]));
//            list.add(new Analysis("technology", tech, platform[i]));
//
//            list.add(new Analysis("learning", learn, platform[i]));
//
//            list.add(new Analysis("food", food, platform[i]));
//
//        }
//
//
//        if(list.size() ==0){
//            return null;
//        }else{
//            return list;
//        }
//
//
//    }
//    @Override
//    public List<Analysis> Analysis4() {
//
//        String platform[]={"quinbook","quinoura","pinstagram"};
//        List<Analysis> list = new ArrayList<>();
//
//        for(int i=0;i<3;i++) {
//            List<UserEntity> list1 = user.findByPlatform(platform[i]);
//
//            int shop = 0, ent = 0, learn = 0, tech = 0, food = 0;
//            for (UserEntity likeAds : list1) {
//                for(String interest:likeAds.getInterests())
//                    if (interest.equalsIgnoreCase("shopping"))
//                        shop +=1;
//                    else if (interest.equalsIgnoreCase("entertainment"))
//                        ent += 1;
//                    else if (interest.equalsIgnoreCase("technology"))
//                        tech +=1;
//                    else if (interest.equalsIgnoreCase("learning"))
//                        learn += 1;
//                    else if (interest.equalsIgnoreCase("food"))
//                        food += 1;
//            }
//            list.add(new Analysis("shopping", shop, platform[i]));
//            list.add(new Analysis("entertainment", ent, platform[i]));
//            list.add(new Analysis("technology", tech, platform[i]));
//
//            list.add(new Analysis("learning", learn, platform[i]));
//
//            list.add(new Analysis("food", food, platform[i]));
//
//        }
//
//
//        if(list.size() ==0){
//            return null;
//        }else{
//            return list;
//        }
//
//
//    }
//    @Override
//    public Brands addBrands(Brands ads) {
//
//
//        Brands ads1 = brand.save(new Brands(ads.getId(),ads.getImages(),ads.getName()));
//        if(ads1.getId()!=null){
//            return ads1;
//        }else {
//            return null;
//        }
//
//
//    }
//
//
//
//    public Ads addAds(Ads ads) {
//
//
//        Ads ads1 = str.save(new Ads(ads.getImage(), ads.getTitle(), ads.getCategory()));
//        if(ads1.getId()!=null){
//            return ads1;
//        }else {
//            return null;
//        }
//
//
//    }
//    public ReturnAfterSavingUser addUser(UserEntity ads) {
//
//        List<UserEntity> userEntity = user.findByUserName(ads.getUserName());
//        if(userEntity.size()==0){
//            UserEntity ads1 = user.save(new UserEntity(ads.getUserName(), ads.getInterests(),ads.getPlatform()));
//            if(ads1.getUserName()!=null){
//                return new ReturnAfterSavingUser(1 , ads);
//            }else {
//                return new ReturnAfterSavingUser(0 , null);
//            }
//        }else{
//            return new ReturnAfterSavingUser(-1 , null);
//        }
//
//
//
//
//    }
//
//
//    public LikeAds addLikes(LikeAds ads) {
//        LikeAds ads1;
//        Optional<LikeAds> ad = strp.findFirstByUsernameAndCategory(ads.getUsername(), ads.getCategory());
//        if (ad.isPresent()) {
//            ad.get().setCount(ad.get().getCount() + 1);
//            ads1=strp.save(ad.get());
//        } else {
//            ads1=strp.save(ads);
//        }
//        if(ads1.getId()!=null){
//            return ads1;
//        }else {
//            return null;
//        }
//    }
//}
