package com.example.Forecast.controller;


import com.example.Forecast.dto.CurrentHourStatus;
import com.example.Forecast.entity.CurrentHourStatusEntity;
import com.example.Forecast.entity.CurrentWeekStatusEntity;
import com.example.Forecast.service.WeatherService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Optional;

@CrossOrigin
@RestController
@RequestMapping("/Weather")
public class WeatherController {



    @Autowired
    WeatherService weather;

    @GetMapping(value="/getCurrent/{city}")
    public Optional<CurrentHourStatusEntity> getCurrentWeather(@PathVariable(value="city") String city) {
        SimpleDateFormat dateformatter = new SimpleDateFormat("yyyy-MM-dd");
        Date date = new Date();
        SimpleDateFormat timeformatter = new SimpleDateFormat("HH");
        Date time = new Date();
//        System.out.println(formatter.format(date));
        Optional<CurrentHourStatusEntity> w=weather.getCurrentWeather(city,dateformatter.format(date), Integer.parseInt(timeformatter.format(time)));
        return w;
    }

    @GetMapping(value="/getRange/{city}")
    public  List<CurrentHourStatusEntity> getRange(@PathVariable(value="city") String city) {
        SimpleDateFormat dateformatter = new SimpleDateFormat("yyyy-MM-dd");
        Date date = new Date();
        SimpleDateFormat timeformatter = new SimpleDateFormat("HH");
        Date time = new Date();
//        System.out.println(formatter.format(date));
        List<CurrentHourStatusEntity> w=weather.getCurrentRange(city,dateformatter.format(date), Integer.parseInt(timeformatter.format(time)));
        return w;
    }
    @GetMapping(value="/getNextSix/{city}")
    public  List<CurrentWeekStatusEntity> getSix(@PathVariable(value="city") String city) {
        SimpleDateFormat dateformatter = new SimpleDateFormat("yyyy-MM-dd");
        Date date = new Date();
//        System.out.println(formatter.format(date));
        List<CurrentWeekStatusEntity> w=weather.getCurrentNextSix(city,dateformatter.format(date));
        return w;
    }
    @PostMapping("/Hour")
    public void addHour(@RequestBody CurrentHourStatusEntity data) {

        weather.addWeatherHour(data);
    }
    @PostMapping("/Week")
    public void addWeek(@RequestBody CurrentWeekStatusEntity data) {

        weather.addWeatherWeek(data);
    }

//        if(ads1.getVal()==1){
//            return new Response<>(ads1.getUserEntity());
//        }else if(ads1.getVal() == 0){
//            return new Response<>(1001 , "Error while Adding User");
//        }else {
//            return new Response<>(1002 , "Already user present");
//        }


    //    @GetMapping(value="/getAds/{category}")
//
//    public Response<List<Ads>> getAllTutorials(@PathVariable(value="category") String[] category) {
//
//        List<Ads> list =  st.getAllAds(category);
//        if(list!=null){
//            return new Response<>(list);
//        }else {
//            return new Response<>(1002 , "Error while fetching the ads");
//        }
//    }
//    @GetMapping("/ads1")
//
//    public Response<List<Ads>> getAllAds() {
//        List<Ads> list=st.getAds();
//        if(list!=null){
//            return new Response<>(list);
//        }else {
//            return new Response<>(1002 , "Error while fetching the all Ads");
//        }
//    }
//
//    @GetMapping("/getBrand")
//
//    public Response<List<Brands>> getBrands() {
//        List<Brands> list=st.getBrands();
//        if(list!=null){
//            return new Response<>(list);
//        }else {
//            return new Response<>(1002 , "Error while fetching the all Brands");
//        }
//    }
//
//    @GetMapping("/getAds")
//
//    public Response<List<Ads>> getAds(@RequestParam String Username) {
//        List<Ads> list=st.getAllAds(Username);
//        if(list!=null){
//            return new Response<>(list);
//        }else {
//            return new Response<>(1002 , "Error while fetching the Ads");
//        }
//    }
//
//    @GetMapping("/getlikes")
//
//    public Response<List<LikeAds>> getAllTutorial() {
//        List<LikeAds> list=st.getAllLikes();
//        if(list!=null){
//            return new Response<>(list);
//        }else {
//            return new Response<>(1002 , "Error while fetching the Likes");
//        }
//    }
//    @GetMapping("/analysis1")
//
//    public Response<List<Analysis>> analysis1() {
//        List<Analysis> list=st.Analysis();
//        if(list!=null){
//            return new Response<>(list);
//        }else {
//            return new Response<>(1002 , "Error while Analysis1");
//        }
//    }
//
//    @GetMapping("/analysis2")
//
//    public Response<List<Analysis>> analysis2() {
//        List<Analysis> list=st.Analysis2();
//        if(list!=null){
//            return new Response<>(list);
//        }else {
//            return new Response<>(1002 , "Error while Analysis2");
//        }
//    }
//    @GetMapping("/analysis3")
//
//    public Response<List<Analysis>> analysis3() {
//        List<Analysis> list=st.Analysis3();
//        if(list!=null){
//            return new Response<>(list);
//        }else {
//            return new Response<>(1002 , "Error while Analysis3");
//        }
//    }
//
//    @GetMapping("/analysis4")
//
//    public Response<List<Analysis>> analysis4() {
//        List<Analysis> list=st.Analysis4();
//        if(list!=null){
//            return new Response<>(list);
//        }else {
//            return new Response<>(1002 , "Error while Analysis4");
//        }
//    }
//    @GetMapping("/getUser")
//
//    public Response<List<UserEntity>> getUser() {
//        List<UserEntity> list=st.getUser();
//        if(list!=null){
//            return new Response<>(list);
//        }else {
//            return new Response<>(1002 , "Error while fetching the User");
//        }
//    }
//
//    @PostMapping("/ads")
//    public Response<Ads> addAds(@RequestBody Ads ads)
//    {
//
//        Ads ads1 = st.addAds(ads);
//        if(ads1!=null){
//            return new Response<>(ads1);
//        }else{
//            return new Response<>(1001 , "Error while Adding Advertisement");
//        }
//    }
//
//    @PostMapping("/addBrands")
//    public Response<Brands> addBrands(@RequestBody Brands ads)
//    {
//
//        Brands ads1 = st.addBrands(ads);
//        if(ads1!=null){
//            return new Response<>(ads1);
//        }else{
//            return new Response<>(1001 , "Error while Adding Brands");
//        }
//    }
//
//    @PostMapping("/User")
//    public Response<UserEntity> addAds(@RequestBody UserEntity ads)
//    {
//
//        ReturnAfterSavingUser ads1 = st.addUser(ads);
//        if(ads1.getVal()==1){
//            return new Response<>(ads1.getUserEntity());
//        }else if(ads1.getVal() == 0){
//            return new Response<>(1001 , "Error while Adding User");
//        }else {
//            return new Response<>(1002 , "Already user present");
//        }
//    }
//
//
//    @PostMapping("/like")
//    public Response<LikeAds> addLikes(@RequestBody LikeAds ads)
//    {
//        LikeAds ads1 = st.addLikes(ads);
//        if(ads1!=null){
//            return new Response<>(ads1);
//        }else{
//            return new Response<>(1001 , "Error while Adding Likes");
//        }
//    }



}
